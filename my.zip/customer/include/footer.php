  <!--footer start-->
<div id="footer">
    <div class="container">
         <div class="row">
             <div class="col-lg-3 mt-3">
             <h4>Pages</h4>
             <ul class="navbar-nav ml-3">
                 <li class="nav-item"><a class="nav-link" href="../shop.php">Shop</a></li>
                 <li class="nav-item"><a class="nav-link" href="my_account.php">My Account</a></li>
                 <li class="nav-item"><a class="nav-link" href="../cart.php">Shoping Cart</a></li>
                 <li class="nav-item"><a class="nav-link" href="../contact.php">Contact Us</a></li>
             </ul>
             <h4>User Section</h4>
             <ul class="navbar-nav ml-3 ">
                 <li class="nav-item"><a class=" nav-link " href="login.php">Login</a></li>
                 <li class="nav-item"><a class="nav-link " href="customer_registration.php">Register</a></li>
             </ul>
             </div>
             <div class="col-lg-3 mt-3">
             <h4>Top Product Categories</h4>
             <ul class="navbar-nav ml-3">
                 <li class="nav-item"><a class="nav-link" href="">Jacket</a></li>
                 <li class="nav-item"><a class="nav-link" href="">Shoes</a></li>
                 <li class="nav-item"><a class="nav-link" href="">T-Shirt</a></li>
                 <li class="nav-item"><a class="nav-link" href="">Coats</a></li>
             </ul>
             
             </div>
             <div class="col-lg-3 mt-3">
             <h4>Where to find us</h4>
             <P>
               <strong>Teehosting.com</strong>
               <br>Naliarchar
               <br>Terokhada
               <br>khulna
               <br> 017000000
             </P>
             <a href="contact.php">Go to contact us page</a> 
             </div>
             <div class="col-lg-3 mt-3 ">
                <h4>Get the news</h4>
                <p> Subscribe her5e for getting news</p>
                <form action="">
                 <div class="input-group">
                    <input type="text"name="email"class="form-control">
                    <span class="input-group-btn">
                    <input type="submit" class="btn btn-primary"value="subscribe">
                    </span>
                 </div>
                </form>
                <br>
                <h4>Stay in toucho</h4>
                <p class="social">
                  <a href=""><i class="fa fa-facebook "></i></a>
                  <a href=""><i class="fa fa-twitter "></i></a>
                  <a href=""><i class="fa fa-instagram "></i></a>
                  <a href=""><i class="fa fa-google "></i></a>
                  <a href=""><i class="fa fa-envelope"></i></a>
                </p>
             </div>
         </div>
    </div>
</div>
<!--footer end-->

<!--copyright stsrt-->
<div id="copyright">
    <div class="container">
        <div class="ends">
        <div class="row d-flex mt-2">
           <div class="col-lg-6 ">
               <p>&copy;Ranjan Kumar Biswas</p>
           </div>
            <div class="col-lg-6 ">
                <div class="end float-right">
                <p>Tamplete by:  <a class="" href="www.teehosting.com">teehosting.com</a></p>
                </div>
            </div>

        </div>
        </div>
    </div>

</div>
<!--copyright end-->
