<div class="panel-heading">
 
     <div class="boxs p-1">
        <img src="image/rai.jpg"class="img-fluid" alt="logo">
        <h3 class="text-center">Name:Ranjan</h3>
     </div>
  

</div >
<div class="panel-body sidebar-menu">
   <ul class="nav nav-pills nav-stacked">
      <li class="nav-item<?php if(isset($_GET['my_order'])){echo"active";}?>">
         <a class="nav-link" href="my_account.php?my_order"><i class="fa fa-list mr-2"></i>My Order</a>
      </li>
      <li class="nav-item<?php if(isset($_GET['pay_offline'])){echo"active";}?>">
          <a class="nav-link" href="my_account.php?pay_offline"><i class="fa fa-bolt"></i>Pay Offline</a>
      </li>
      <li class="nav-item<?php if(isset($_GET['my_adress'])){echo"active";}?>">
          <a class="nav-link" href="my_account.php?my_adress"><i class="fa fa-user"></i>My Adress</a>
      </li>
      <li class="nav-item<?php if(isset($_GET['edit_account'])){echo"active";}?>">
          <a class="nav-link" href="my_account.php?edit_account"><i class="fa fa-pencil"></i>Edit Account</a>
      </li>
      <li class="nav-item<?php if(isset($_GET['change_pass'])){echo"active";}?>">
          <a class="nav-link" href="my_account.php?change_pass"><i class="fa fa-user"></i>Change Password</a>
      </li>
      <li class="nav-item<?php if(isset($_GET['delete_account'])){echo"active";}?>">
          <a class="nav-link" href="my_account.php?delete_account"><i class="fa fa-trace-o"></i>Delete Account</a>
      </li>
      <li class="nav-item<?php if(isset($_GET['logout'])){echo"active";}?>">
          <a class="nav-link" href="my_account.php?logout"><i class="fa fa-sign-out"></i>Logout</a>
      </li>
   </ul>
</div>