<div class="boxs">
   <h1 class="text-center">Edit Your Account</h1>
</div>
<div class="form-group">
 <label >Name</label>
 <input type="text"name="c_name"class="form-control"required>
</div>
<div class="form-group">
<label >Email</label>
 <input type="email"name="c_email"class="form-control"required>
</div>
<div class="form-group">
<label >Password</label>
 <input type="password"name="c_password"class="form-control"required>
</div>
<div class="form-group">
<label >Name</label>
 <input type="text"name="c_name"class="form-control"required>
</div>
<div class="form-group">
<label >Name</label>
 <input type="text"name="c_name"class="form-control"required>
</div>
<div class="form-group">
<label >Image</label>
 <input type="file"name="c_image"class="form-control"required>
 <img class="img-fluid" src="image/bip.jpg" alt="">
</div>
<div class="form-group text-center">
<button class="btn btn-primary"name="update">Update Now</button>
</div>