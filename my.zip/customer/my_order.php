<div class="boxs">
    <h1 class="text-center">My Order</h1>
    <p  class="text-center">Lorem ipsum dolor sit amet consectetur <a href="../contact.php">contact us</a> adipisicing elit. Asperiores, ad.</p>
</div>

<div class="table-responsive">
    <table class="table table-bordered table-hover">
       <thead>
           <tr>
              <th> sr.no</th>
              <th> due amount</th>
              <th> invoice number</th>
              <th>quantity</th>
              <th> size</th>
              <th> order date</th>
              <th> paid</th>
              <th> status</th>
           </tr>
       </thead>
       <tbody>
          <tr>
             <td>#1</td>
             <td>Tk 200</td>
             <td>51512</td>
             <td>2</td>
             <td>larze</td>
             <td>2021-05-24</td>
             <td>unpaid</td>
             <td><a href="confirm.php" target="_blank"class="btn btn-primary btn-sm">confirm if paid</a></td>
          </tr>
          <tr>
             <td>#2</td>
             <td>Tk 200</td>
             <td>51513</td>
             <td>2</td>
             <td>larze</td>
             <td>2021-05-24</td>
             <td>unpaid</td>
             <td><a href="confirm.php" target="_blank"class="btn btn-primary btn-sm">confirm if paid</a></td>
          </tr>
          <tr>
             <td>#3</td>
             <td>Tk 200</td>
             <td>51514</td>
             <td>2</td>
             <td>larze</td>
             <td>2021-05-24</td>
             <td>unpaid</td>
             <td><a href="confirm.php" target="_blank"class="btn btn-primary btn-sm">confirm if paid</a></td>
          </tr>
       </tbody>
    </table>
</div>