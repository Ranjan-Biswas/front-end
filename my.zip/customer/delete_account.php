<div class="boxs">
 <h1 class="text-center">Are you sure delete account</h1>
</div>
<form action=""method="post"class="text-center">
  <input type="submit"name="yes"value="yes,i want to delete"class="btn btn-danger">
  <input type="submit"name="no"value="no,i dont want"class="btn btn-primary">
</form>