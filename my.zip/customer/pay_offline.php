<div class="boxs">
 <h1 class="text-center ">Pay off line</h1>
 <p  class="text-center">Lorem ipsum dolor sit amet consectetur <a href="../contact.php">contact us</a> adipisicing elit. Asperiores, ad.</p>
</div>