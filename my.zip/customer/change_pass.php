<div class="boxs">
 <h1>Change Your Password</h1>
</div>
<div class="form-group">
   <label>Enter Your Password</label>
   <input type="password" name="old_password"class="form-control">
</div>

<div class="form-group">
   <label>Enter Your New Password</label>
   <input type="password" name="new_password"class="form-control">
</div>

<div class="form-group">
   <label>confirm Your New Password</label>
   <input type="password" name="c_n_password"class="form-control">
</div>
<div class="form-gorup text-center">
 <button class="btn btn-primary"name="update">Update now</button>
</div>