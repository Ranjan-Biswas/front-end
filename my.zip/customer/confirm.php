<!doctype html>
<html lang="en">
  <head>
    <title>full project 1</title>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" type="text/css"href="css/style.css">
 </head>
  <body>
    <!--top bar start-->
     <div id="top">
       <div class="container"><!--container start-->
         <div class="row">
           <div class="col-lg-6 m-auto">
              <a href=""class="btn btn-success btn-sm text-white mr-2">WELLCOME GUEST</a>
              <a class="text-white" href="">Shoping Cart Total Price $100,Total Item 2</a>
            </div>
            <div class="col-lg-6">
               <ul class="nav  float-right">
                 <li class="nav-item"><a class="rai nav-link " href="../customer_registration.php">Register</a></li>
                 <li class="nav-item"><a class="rai nav-link  " href="my_account.php">my Account</a></li>
                 <li class="nav-item" ><a class="rai nav-link" href="../cart.php">Shoping</a></li>
                 <li class="nav-item"><a class="rai nav-link " href="../login.php">Login</a></li>
               </ul>
          </div>
         </div>
       </div><!--container end-->
     </div>
    <!--top bar end-->

     <!--nav bar start-->
     <div id="navbar">
        <div class="container">
        <nav class="navbar navbar-expand-sm navbar-light">
  <a class="navbar-brand" href="#">Navbar</a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
    <span><i class="fa fa-bars"></i></span>
  </button>

  <div class="collapse navbar-collapse" id="navbarSupportedContent">
    <ul class="navbar-nav ml-auto">
      <li class="nav-item "><a class="nav-link" href="../index.php">Home </a></li>
      <li class="nav-item"><a class="nav-link" href="../shop.php">Shop</a></li>
      <li class="nav-item active"><a class="nav-link" href="my_account.php">My Account</a></li>
      <li class="nav-item"><a class="nav-link" href="../cart.php">Shoping Cart</a></li>
      <li class="nav-item"><a class="nav-link" href="../about.php">About Us</a></li>
      <li class="nav-item"><a class="nav-link" href="../service.php">Services</a></li>
      <li class="nav-item"><a class="nav-link" href="../contact.php">Contuct Us</a></li>
    </ul>
  </div>
</nav>
 </div>
</div>
<!--nav bar end-->

<div class="content">
   <div class="container">
      <div class="row">
         <div class="col-lg-12">
            <div class="breadcrumb">
              <li class="nav-item "><a class="nav-link" href="../index.php">Home </a></li>
              <li class="nav-item active"><a class="nav-link" href="my_account.php">My Account</a></li>
            </div>
         </div>
      </div>
   </div>
</div>


<div class="container">
 <div class="row">
   <div class="col-lg-3">
        <!--sidebar start-->
        <?php
            include("include/sidebar.php")
        ?>
       <!--sidebar end-->
   </div>
      <div class="col-lg-9"> <!--col-lg-9 confirm start-->
         <div class="boxs">
             <h1>Please confirm your payment</h1>
             </div>
             <form action="confirm.php" method="post"enctype="multipart/form-data">
             <div class="form-group">
              <label for="">invoice number</label>
              <input type="text"class="form-control"name="invoice-number"required>
              </div>
              <div class="form-group">
              <label for="">Amount</label>
              <input type="text"class="form-control"name="amount"required>
              </div>
              <div class="form-group">
              <label for="">Select payment method</label>
                 <select class="form-control"name="amount"required>
                    <option >bank-transfer</option>
                    <option >paypal</option>
                    <option >payumoney</option>
                    <option >paytm</option>
                  </select>
              </div>
              <div class="form-group">
              <label for="">Date</label>
              <input type="date"class="form-control"name="date"required>
              </div>
                <div class="text-center">
                    <button type="submit"name="confirm-payment"class="btn btn-primary btn-lg">
                        Confirn Payment
                    </button>
                
             </form>
         </div>
      </div> <!--col-lg-9 confirm end-->

   </div>
</div>

 
 
 
 <!--footer start-->


  <?php
   include("include/footer.php")

  ?>
  <!--footer end-->
    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
  </body>
</html>