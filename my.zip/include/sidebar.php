<div class="panel panel-default sidebar-menu "><!--Product Category start-->
   <div class="panel-heading">
       <h3 class="medium">Product Category</h3>
   </div>
   <div class="panel-body">
      <ul class="navbar-nav ml-3">
      <li class="nav-item"><a class="nav-link" href="shop.php">T-Shirt</a></li>
      <li class="nav-item"><a class="nav-link" href="shop.php">Jacket</a></li>
      <li class="nav-item "><a class="nav-link" href="shop.php">Coats</a></li>
      <li class="nav-item"><a class="nav-link" href="shop.php">Tops</a></li>
      </ul>
   </div>
</div><!--Product Category start-->
<div class="panel panel-default sidebar-menu mt-3 "><!-- Category start-->
   <div class="panel-heading">
       <h3 class="medium"> Category</h3>
   </div>
   <div class="panel-body">
      <ul class="navbar-nav ml-3">
      <li class="nav-item"><a class="nav-link" href="shop.php">Men</a></li>
      <li class="nav-item"><a class="nav-link" href="shop.php">Women</a></li>
      <li class="nav-item "><a class="nav-link" href="shop.php">Kids</a></li>
      <li class="nav-item"><a class="nav-link" href="shop.php">Others</a></li>
      </ul>
   </div>
</div><!-- Category end-->