
<!doctype html>
<html lang="en">
  <head>
    <title>full project 1</title>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" type="text/css"href="css/style.css">
 </head>
  <body>
    <!--top bar start-->
     <div id="top">
       <div class="container"><!--container start-->
         <div class="row">
           <div class="col-lg-6 m-auto">
              <a href="" class="btn btn-success btn-sm text-white mr-2">WELLCOME GUEST</a>
              <a  href="" class="text-white">Shoping Cart Total Price $100,Total Item 2</a>
            </div>
            <div class="col-lg-6">
               <ul class="nav  float-right">
                 <li class="nav-item"><a class="rai nav-link " href="customer_registration.php">Register</a></li>
                 <li class="nav-item"><a class="rai nav-link  " href="customer/my_account.php">my Account</a></li>
                 <li class="nav-item" ><a class="rai nav-link" href="cart.php">Shoping</a></li>
                 <li class="nav-item"><a class="rai nav-link " href="login.php">Login</a></li>
               </ul>
          </div>
         </div>
       </div><!--container end-->
     </div>
    <!--top bar end-->

     <!--nav bar start-->
     <div id="navbar">
        <div class="container">
        <nav class="navbar navbar-expand-sm navbar-light">
  <a class="navbar-brand" href="#">Navbar</a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
    <span><i class="fa fa-bars"></i></span>
  </button>

  <div class="collapse navbar-collapse" id="navbarSupportedContent">
    <ul class="navbar-nav ml-auto">
      <li class="nav-item active"><a class="nav-link" href="index.php">Home </a></li>
      <li class="nav-item"><a class="nav-link" href="shop.php">Shop</a></li>
      <li class="nav-item"><a class="nav-link" href="customer/my_account.php">My Account</a></li>
      <li class="nav-item"><a class="nav-link" href="cart.php">Shoping Cart</a></li>
      <li class="nav-item"><a class="nav-link" href="about.php">About Us</a></li>
      <li class="nav-item"><a class="nav-link" href="service.php">Services</a></li>
      <li class="nav-item"><a class="nav-link" href="contact.php">Contact Us</a></li>
    </ul>
  </div>
</nav>
        </div>
     </div>
     <!--nav bar end-->

      <!--slider start-->
  <div class="container"id="slider">
  <div id="carouselExampleIndicators" class="carousel slide" data-ride="carousel">
  <ol class="carousel-indicators">
    <li data-target="#carouselExampleIndicators" data-slide-to="0" class="active"></li>
    <li data-target="#carouselExampleIndicators" data-slide-to="1"></li>
    <li data-target="#carouselExampleIndicators" data-slide-to="2"></li>
  </ol>
  <div class="carousel-inner">
    <div class="carousel-item active">
      <img class="d-block w-100 cimg" src="image/rai.jpg" alt="First slide">
    </div>
    <div class="carousel-item">
      <img class="d-block w-100 cimg" src="image/ran.jpg" alt="Second slide">
    </div>
    <div class="carousel-item">
      <img class="d-block w-100 cimg" src="image/bip.jpg" alt="Third slide">
    </div>
  </div>
  <a class="carousel-control-prev" href="#carouselExampleIndicators" role="button" data-slide="prev">
    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
    <span class="sr-only">Previous</span>
  </a>
  <a class="carousel-control-next" href="#carouselExampleIndicators" role="button" data-slide="next">
    <span class="carousel-control-next-icon" aria-hidden="true"></span>
    <span class="sr-only">Next</span>
  </a>
 </div>
  </div>
 <!--slider end-->

 <!--advanteg start-->
 <div id="advanteg">
    <div class="container">
        <div class="row mt-5">
           <div class="col-lg-4 d-block d-lg-flex">
              <div class="box text-center">
                <div class="icon">
                  <i class="fa fa-heart"></i>
                </div>
                <h3>BEST PRICE</h3>
                <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Impedit, veritatis.</p>
              </div>
           </div>
           <div class="col-lg-4 d-block d-lg-flex">
              <div class="box text-center">
                <div class="icon">
                  <i class="fa fa-heart"></i>
                </div>
                <h3>100% SATIDFFACTION GUARANTED FROM US</h3>
                <p>Lorem ipsum dolor sit amet.</p>
              </div>
           </div>
           <div class="col-lg-4 d-block d-lg-flex ">
              <div class="box text-center">
                <div class="icon">
                  <i class="fa fa-heart"></i>
                </div>
                <h3>WE LOVE OUR CUSTOMER</h3>
                <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Sequi et velit nam!</p>
              </div>
           </div>
        </div>
    </div>
 </div>
 <!--advanteg end-->

 <!--hot box start-->
<div id="hotbox">
   <div class="latest">
     <div class="container">
         <h2 class="text-center mt-5 lat">LATEST THIS WEEK</h2>
     </div> 
  </div>
</div>
  <!--hot box end-->

  <!--product start-->

  <div id="content">
    <div class="container ">
        <div class="row mt-3">
           <div class="col-lg-3">
               <div class="product">
                   <a href="details.php"><img class="img-fluid" src="image/ran.jpg" alt="logo"></a>
                      <div class="text-center">
                        <h3><a href="details.php">BENETTON WHITE POLO SHIRT</a></h3>
                          <p class="price">TK 299</p> 
                          <p class="buttons">
                            <a href="details.php"class="btn btn-secondary btn-sm">View Details</a>
                            <a href="details.php"class="btn btn-primary btn-sm"><i class="fa fa-shopping-cart mr-1"></i>Add to cart</a>
                          </p>
                      </div>
                  </div>
           </div>
           <div class="col-lg-3">
               <div class="product">
                   <a href="details.php"><img class="img-fluid" src="image/ran.jpg" alt="logo"></a>
                      <div class="text-center">
                        <h3><a href="details.php">BENETTON WHITE POLO SHIRT</a></h3>
                          <p class="price">TK 299</p> 
                          <p class="buttons">
                            <a href="details.php"class="btn btn-secondary btn-sm">View Details</a>
                            <a href="details.php"class="btn btn-primary btn-sm"><i class="fa fa-shopping-cart mr-1"></i>Add to cart</a>
                          </p>
                      </div>
                  </div>
           </div>
           <div class="col-lg-3">
               <div class="product">
                   <a href="details.php"><img class="img-fluid" src="image/ran.jpg" alt="logo"></a>
                      <div class="text-center">
                        <h3><a href="details.php">BENETTON WHITE POLO SHIRT</a></h3>
                          <p class="price">TK 299</p> 
                          <p class="buttons">
                            <a href="details.php"class="btn btn-secondary btn-sm">View Details</a>
                            <a href="details.php"class="btn btn-primary btn-sm"><i class="fa fa-shopping-cart mr-1"></i>Add to cart</a>
                          </p>
                      </div>
                  </div>
           </div>
           <div class="col-lg-3">
               <div class="product">
                   <a href="details.php"><img class="img-fluid" src="image/ran.jpg" alt="logo"></a>
                      <div class="text-center">
                        <h3><a href="details.php">BENETTON WHITE POLO SHIRT</a></h3>
                          <p class="price">TK 299</p> 
                          <p class="buttons">
                            <a href="details.php"class="btn btn-secondary btn-sm">View Details</a>
                            <a href="details.php"class="btn btn-primary btn-sm"><i class="fa fa-shopping-cart mr-1"></i>Add to cart</a>
                          </p>
                      </div>
                  </div>
           </div>
        </div>
    </div>
  </div>
    <!--product end-->

    
  <!--footer start-->
  <?php
   include("include/footer.php")

  ?>
  <!--footer end-->
    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
  </body>
</html>